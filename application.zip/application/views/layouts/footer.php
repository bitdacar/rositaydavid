<footer class="main-footer">
	<strong>Copyright &copy; 2024</strong>
	Todos los derechos reservados.
	<div class="float-right d-none d-sm-inline-block">
		<b>Version</b> 1.0.0
	</div>
</footer>

<!-- Control Sidebar -->
 <!-- PNotify -->
    <script src="<?php echo base_url();?>assets/template/pnotify/dist/pnotify.js"></script>
    <script src="<?php echo base_url();?>assets/template/pnotify/dist/pnotify.buttons.js"></script>
    <script src="<?php echo base_url();?>assets/template/pnotify/dist/pnotify.nonblock.js"></script>
	<script src="<?php echo base_url();?>assets/template/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url();?>assets/template/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/template/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url();?>assets/template/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url();?>assets/template/datatables.net-buttons/js/buttons.print.min.js"></script>
<!-- /.control-sidebar -->


</body>

</html>
