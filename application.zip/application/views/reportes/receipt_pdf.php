        
                    
<?php 
echo $encabezado;
echo $cliente;
echo $tabla;


?>