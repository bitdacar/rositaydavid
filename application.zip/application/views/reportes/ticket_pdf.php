
                    
<?php 
echo $encabezado;
//echo $cliente;
echo $tabla;


?>


</div>
</div>
</div>

</div>
</div>
</div>

